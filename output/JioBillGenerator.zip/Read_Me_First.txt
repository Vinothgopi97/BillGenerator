Requirements:
Java (OpenJDK installed) - Version 22 is recommended

Step 1:
 Open CMD or terminal in the folder where BillGenerator.jar file and input.properties files are located

Step 2:
	update the input.properties file accordingly with your bill details like bill number, invoice date and due date etc,

Step 3:
	Run the below command and the PDF file will be generated in the same folder
	java -jar .\BillGenerator.jar .\input.properties